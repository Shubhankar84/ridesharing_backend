const RideServices = require("../services/rideServices");

exports.createRide = async (req, res, next)  => {
    try {
        const {userId, source, dest, date} = req.body;
        let ride = await RideServices.createRide(userId, source, dest, date);

        res.json({status:true, success:ride});
    } catch (error) {
        next(error);
    }
}

// exports.getUserTodo = async (req, res, next)  => {
//     try {
//         const {userId} = req.body;
//         let toDo = await ToDoservices.getTododata(userId);

//         res.json({status:true, success:toDo});
//     } catch (error) {
//         next(error);
//     }
// }