const router = require('express').Router();
const RideController = require('../controller/ridesController');

router.post('/createride', RideController.createRide);


module.exports = router;