const RideModel = require('../model/rides_model');

class RideServices{
    static async createRide(userId, source, dest, date){
        const createRide = new RideModel({userId, source, dest, date});
        return await createRide.save();
    }

    // static async getTododata(userId){
    //     const todoData = await ToDoModel.find({userId});
    //     return todoData;
    // }
}

module.exports = RideServices;